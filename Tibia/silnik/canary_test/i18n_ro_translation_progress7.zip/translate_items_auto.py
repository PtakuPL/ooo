import json
import re
import sys

# Simple RO translations for common words/phrases.
# This is intentionally conservative to avoid breaking proper nouns.
BASE = {
    "your inbox": "cutia ta poștală",
    "market": "piață",
    "rum": "rom",
    "beer bottle": "sticlă de bere",
    "empty beer bottle": "sticlă goală de bere",
    "fruit juice": "suc de fructe",
    "coconut milk": "lapte de cocos",
    "mead": "hidromel",
    "cigar": "trabuc",
    "parcel": "pachet",
    "bar of gold": "lingou de aur",
    "shovel": "lopată",
    "ladder": "scară",
    "stairs": "scări",
    "wall": "perete",
    "floor": "podea",
    "door": "ușă",
    "open door": "ușă deschisă",
    "closed door": "ușă închisă",
    "archway": "arcadă",
    "mushrooms": "ciuperci",
    "mushroom": "ciupercă",
    "crystals": "cristale",
    "crystal": "cristal",
    "basalt wall": "perete de bazalt",
    "basalt floor": "podea de bazalt",
    "icy wall": "perete înghețat",
    "ice stone floor": "podea de piatră înghețată",
    "lava": "lavă",
    "foxtail": "coadă de vulpe",
    "four-leaf clover": "trifoi cu patru foi",
    "dog collar": "zgardă de câine",
    "bell": "clopot",
    "purse": "poșetă",
    "pouch": "punguță",
    "flower pot": "ghiveci de flori",
    "withered plant": "plantă ofilită",
    "green crystals": "cristale verzi",
    "blue crystals": "cristale albastre",
    "red crystals": "cristale roșii",
    "small green crystals": "cristale verzi mici",
    "small blue crystals": "cristale albastre mici",
    "small red crystals": "cristale roșii mici",
    "cluster of green crystals": "grup de cristale verzi",
    "cluster of blue crystals": "grup de cristale albastre",
    "cluster of red crystals": "grup de cristale roșii",
    "green crystal rods": "tije de cristal verde",
    "blue crystal rods": "tije de cristal albastru",
    "red crystal rods": "tije de cristal roșu",
    "large blue crystal": "cristal albastru mare",
    "crystal wall": "perete de cristal",
    "crystal lamp": "lampă de cristal",
    "lit crystal lamp": "lampă de cristal aprinsă",
    "glowing mushroom": "ciupercă luminoasă",
    "lit glowing mushroom": "ciupercă luminoasă aprinsă",
}

# Word-level translations for safe partial conversions.
WORD = {
    "dead": "mort",
    "trophy": "trofeu",
    "seed": "sămânță",
    "seeds": "semințe",
    "key": "cheie",
    "library": "bibliotecă",
    "drowned": "înecată",
    "hive": "stup",
    "insectoid": "insectoid",
    "worker": "muncitor",
    "warrior": "războinic",
    "guard": "gardian",
    "spellsinger": "cântăreț de vrăji",
    "staff": "toiag",
    "axe": "topor",
    "sword": "sabie",
    "bow": "arc",
    "crossbow": "arbaletă",
    "shield": "scut",
    "belt": "centură",
    "necklace": "colier",
    "ring": "inel",
    "helmet": "coif",
    "armor": "armură",
    "legs": "pantaloni",
    "boots": "cizme",
    "backpack": "rucsac",
    "stone": "piatră",
    "mud": "noroi",
    "water": "apă",
    "strong": "puternic",
    "vortex": "vârtej",
    "black": "negru",
    "deep": "adânc",
}

# Patterns -> formatters
PATTERNS = [
    # dead <name>
    (re.compile(r"^dead (.+)$", re.IGNORECASE), lambda m: f"{m.group(1)} mort"),
    # trophy of <name>
    (re.compile(r"^trophy of (.+)$", re.IGNORECASE), lambda m: f"trofeu al lui {m.group(1)}"),
    # key to the <name>
    (re.compile(r"^key to the (.+)$", re.IGNORECASE), lambda m: f"cheie pentru {m.group(1)}"),
    # flask of <x>
    (re.compile(r"^flask of (.+)$", re.IGNORECASE), lambda m: f"flacon de {m.group(1)}"),
    # bag of <x>
    (re.compile(r"^bag of (.+)$", re.IGNORECASE), lambda m: f"sac cu {m.group(1)}"),
    # bucket of <x>
    (re.compile(r"^bucket of (.+)$", re.IGNORECASE), lambda m: f"găleată cu {m.group(1)}"),
]


def translate_phrase(s: str) -> str | None:
    s = s.strip()
    # exact
    if s in BASE:
        return BASE[s]

    # pattern rules
    for rx, fn in PATTERNS:
        m = rx.match(s)
        if m:
            out = fn(m)
            # small safe post-processing: translate a few known words inside
            out = out.replace("the ", "")
            return out

    # conservative word-by-word only if phrase is simple (1-3 words)
    parts = s.split()
    if 1 <= len(parts) <= 3:
        out_parts = []
        changed = False
        for p in parts:
            key = p.lower()
            if key in WORD:
                tr = WORD[key]
                # keep capitalization for first word
                if p[0].isupper():
                    tr = tr[0].upper() + tr[1:]
                out_parts.append(tr)
                changed = True
            else:
                out_parts.append(p)
        if changed:
            return " ".join(out_parts)

    return None


def main(path: str):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    changed = 0
    for k, v in list(data.items()):
        if isinstance(v, str) and v.startswith("[RO] "):
            eng = v[5:]
            tr = translate_phrase(eng)
            if tr and tr != eng:
                data[k] = tr
                changed += 1

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f"Translated {changed} entries in {path}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python translate_items_auto.py <items.json>")
        sys.exit(2)
    main(sys.argv[1])
